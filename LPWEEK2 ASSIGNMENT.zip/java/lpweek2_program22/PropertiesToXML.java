package lpweek2_program22;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;
 
public class PropertiesToXML 
{
    
	public static void main(String[] args) throws 
                                     InvalidPropertiesFormatException, IOException 
    {
        String inPropertiesFile = "configuration.properties";
        String outXmlFile = "configurationproperty.xml";
 
        InputStream is = new FileInputStream(inPropertiesFile); //Input file
        OutputStream os = new FileOutputStream(outXmlFile);     //Output file
         
        Properties props = new Properties();
        props.load(is);
         
        props.storeToXML(os, "configuration.properties","UTF-8");
    }
}
