package lpweek2_program26;

import java.util.HashSet;
import java.util.Scanner;

public class UniqueCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		String input=scan.next();
		int len=input.length();
		
		char inputArray[]=input.toCharArray();
		HashSet <Character>input_set=new HashSet<Character>();
		for(int index=0;index<len;index++)
		{
			input_set.add(inputArray[index]);
			
		}
		if(input_set.size()==len)
		{
			System.out.println("Yes");
		}
		else
			System.out.println("No");
		scan.close();
	}


}
