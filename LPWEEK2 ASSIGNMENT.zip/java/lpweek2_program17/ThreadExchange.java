package lpweek2_program17;



import java.util.Scanner;
import java.util.Stack;
class Assigner implements Runnable{

		public void run() {
			System.out.println("assigner");
			if(!ThreadExchange.bucket.isEmpty()) {
				System.out.println(ThreadExchange.bucket.pop());
			}
			
		}

	}
class Checker implements Runnable{

		public void run() {
			System.out.println("checker");
			int bulbCount = ThreadExchange.productionCount;
			System.out.println(bulbCount);
			for(int ctr=0;ctr<bulbCount;ctr++) {
			
			   ThreadExchange.bucket.add("bulb");
			}
			
		
		}
			
	}
public class  ThreadExchange {
	static Stack<String> bucket = new Stack<String>();
	
    static int productionCount = 0;
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		String production;
		do {
			Assigner assigner = new Assigner();
			Checker checker = new Checker();
			 production = scanner.nextLine();
			productionCount = scanner.nextInt();
			System.out.println("thraed1");
			Thread thread1 = new Thread(checker);
			System.out.println("thraed2");
			Thread thread2 = new Thread(assigner);
			thread1.start();
			try {
				thread1.join();
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			thread2.start();
			
		}
		while(!production.equals("stop"));
		System.out.println(bucket);
		scanner.close();
   
	}

}

