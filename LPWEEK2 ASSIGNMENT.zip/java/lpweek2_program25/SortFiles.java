package lpweek2_program25;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortFiles {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader reader=new FileReader("C:/Users/Admin/Documents/sortingFile.txt");
		BufferedReader input=new BufferedReader(reader);
		List<String>list=new ArrayList<String>();
		String str;
		while((str=input.readLine())!=null)
		{
			list.add(str);
		}
		 Collections.sort(list);
	    
		FileWriter writer=new FileWriter("C:/Users/Admin/Documents/sortingFile.txt");
	     for(String value:list)
	     {
	    	 writer.write(value);
	     }
       input.close();
     
       
       
	}

}
