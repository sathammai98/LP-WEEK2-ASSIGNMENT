package lpweek2_program21;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class InsertIntoFiles {
public static void main(String[] args) throws IOException{
File file=new File("C:/Users/Admin/Documents/sortingFile.txt");
file.createNewFile();
FileReader reader=new FileReader(file);
BufferedReader br=new BufferedReader(reader);
String str=br.readLine();
str=str+"123";
//System.out.println(str);
FileWriter writer=new FileWriter("C:/Users/Admin/Documents/sortingFile.txt");
writer.write(str);
writer.close();
br.close();
}

}

 