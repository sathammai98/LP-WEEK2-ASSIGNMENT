package lpweek2_program23;

import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException; 
import java.util.Properties;
import java.util.Scanner;
 

public class CreateProperty {
 
	public static void main(String args[]) throws IOException {
		Scanner scan=new Scanner(System.in);
		System.out.println("Creating properties file");
		System.out.println("-----------------------------");
		Properties prop = new Properties();
		for(int index=0;index<4;index++)
		{
			prop.setProperty(scan.next(), scan.next());
		}
 
		try {
			
			prop.store(new FileOutputStream("configuration.properties"),null);
		} catch (FileNotFoundException e) {
 
			e.printStackTrace();
		} catch (IOException e) {
 
			e.printStackTrace();
		} finally {
			System.out.println("PROCESS IS OVER");
		}
		scan.close();
	}
 
}	
		
 
	
 