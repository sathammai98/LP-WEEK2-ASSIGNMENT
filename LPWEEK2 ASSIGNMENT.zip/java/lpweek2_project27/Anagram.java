package lpweek2_project27;

import java.util.Scanner;
import java.util.TreeSet;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		String input1=scan.nextLine();
		int len1=input1.length();
		String input2=scan.nextLine();
		int len2=input2.length();
		char inputArray1[]=input1.toCharArray();
		char inputArray2[]=input2.toCharArray();
		TreeSet <Character>input1_set=new TreeSet<Character>();
		TreeSet <Character>input2_set=new TreeSet<Character>();
		for(int index=0;index<len1;index++)
		{
			if(inputArray1[index]!=' ')
			input1_set.add(inputArray1[index]);
		}
		for(int index=0;index<len2;index++)
		{
			if(inputArray2[index]!=' ')
			{
			input2_set.add(inputArray2[index]);
			}
		}
		if(input1_set.containsAll(input2_set))
		{
			System.out.println("Yes");
		}
			
		else
			System.out.println("No");
		scan.close();

	}

}
