package lpweek2_project28;

import java.util.Scanner;

public class InitialsFromName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		String input=scan.nextLine();
		StringBuilder str=new StringBuilder();
		str.append(input.charAt(0));
		for(int index=0;index<input.length();index++)
		{
			if(input.charAt(index)==' '&&(index+1)<input.length())
			{
				str.append(input.charAt(index+1));
			}
		}
      System.out.println(str.toString().toUpperCase());
      scan.close();
	}


}
 