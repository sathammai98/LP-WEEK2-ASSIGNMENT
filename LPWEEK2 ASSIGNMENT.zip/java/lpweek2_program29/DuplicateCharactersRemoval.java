package lpweek2_program29;

import java.util.LinkedHashSet;
import java.util.Scanner;

public class DuplicateCharactersRemoval {
  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				Scanner scan=new Scanner(System.in);
				String input=scan.next();
				int len=input.length();
				char inputArray[]=input.toCharArray();
				LinkedHashSet <Character>input_set=new LinkedHashSet<Character>();
				for(int index=0;index<len;index++)
				{
					input_set.add(inputArray[index]);
					
				}
				String str=input_set.toString();
				System.out.println(str);
				scan.close();
	}

}
