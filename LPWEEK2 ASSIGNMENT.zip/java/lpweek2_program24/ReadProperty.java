package lpweek2_program24;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadProperty {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Properties prop = new Properties();
		FileReader file=new FileReader("configuration.properties");
		prop.load(file);
		System.out.println(prop.getProperty("USER"));
	}

}
